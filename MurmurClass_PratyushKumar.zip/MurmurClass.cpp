#include "MurmurClass.h"


// implementation kept in header file due to ease with templates